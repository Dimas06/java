/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

/**
 *
 * @author dimas_06
 */
interface FirstInterface {
  public void mySuara(); // interface method
}

interface SecondInterface {
  public void myOtherSuara(); // interface method
}

class Suara implements FirstInterface, SecondInterface {
  public void mySuara() {
    System.out.println("saya terluka karena..");
  }
  public void myOtherSuara() {
    System.out.println("terjatuh dari jurang dengan ketinggian 3339 mdpl ...");
  }
}

class MyMain {
  public static void main(String[] args) {
    Suara myObj = new Suara();
    myObj.mySuara();
    myObj.myOtherSuara();
  }
}
