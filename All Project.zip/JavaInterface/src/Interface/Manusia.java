/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

/**
 *
 * @author dimas_06
 */
interface Manusia {
  public void manusiaSound(); // interface method (does not have a body)
  public void sleep(); // interface method (does not have a body)
}

// Pig "implements" the Manusia interface
class Cowok implements Manusia {
  public void manusiaSound() {
    // The body of animalSound() is provided here
    System.out.println("The sakrip says: hey kau");
  }
  public void sleep() {
    // The body of sleep() is provided here
    System.out.println("khkhkhkh");
  }
}

class MyMainClass {
  public static void main(String[] args) {
    Cowok myCowok = new Cowok();  // Create a Pig object
    myCowok.manusiaSound();
    myCowok.sleep();
  }
}