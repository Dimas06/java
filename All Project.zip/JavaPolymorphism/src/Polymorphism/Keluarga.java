/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Polymorphism;

/**
 *
 * @author dimas_06
 */
public class Keluarga {
    public void keluargaSound() {
    System.out.println("The keluarga makes a sound");
  }
}

class Ayah extends Keluarga {
  public void keluargaSound() {
    System.out.println("The ayah says: hei ibu, dimana budi ?");
  }
}

class Ibu extends Keluarga {
  public void keluargaSound() {
    System.out.println("The ibu says: dia sedang membobol Atm");
  }
}

class Kakak extends Keluarga {
  public void keluargaSound() {
    System.out.println("The kakak says: itu perbuatan yang tidak baik");
  }
}

class MyMainClass {
  public static void main(String[] args) {
    Keluarga myKeluarga = new Keluarga();  // Create a Animal object
    Keluarga myAyah = new Ayah();  // Create a Pig object
    Keluarga myIbu = new Ibu();// Create a Dog object
    Keluarga myKakak = new Kakak();
    myKeluarga.keluargaSound();
    myAyah.keluargaSound();
    myIbu.keluargaSound();
    myKakak.keluargaSound();
  }
}
