/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BufferReader;
import java.io. *;
/**
 *
 * @author dimas_06
 */
public class input_example {
    public static void main(String[] args){
        //Membuat Objek dari Class BufferedReader
        BufferedReader input =
        new BufferedReader (new InputStreamReader(System.in));
        String Nama,Alamat,Jurusan,JenisKelamin,Angkatan,Nim;
        try  
            {
        System.out.println("Nama                  :");
        Nama = input.readLine();
        
        System.out.println("Alamat                :");
        Alamat = input.readLine();
        
        System.out.println("Jurusan               :"); 
        Jurusan = input.readLine();
    
        System.out.println("JenisKelamin          :"); 
        JenisKelamin = input.readLine();
        
        System.out.println("NIM                   :");
        Nim = input.readLine();   
        
        System.out.println("Angkatan              :");
        Angkatan = input.readLine();//Mendapatkan Input dari User
        
        System.out.println("Nim                   :"+Nim);
        System.out.println("Nama                  :"+Nama);
        System.out.println("Alamat                :"+Alamat);
        System.out.println("Jurusan               :"+Jurusan);
        System.out.println("Angkatan              :"+Angkatan);
        System.out.println("JenisKelamin          :"+JenisKelamin);
        System.out.println("BUFFERED READER!!!!");
        }catch (IOException ex){
         
        
        
    }
  }
}   
