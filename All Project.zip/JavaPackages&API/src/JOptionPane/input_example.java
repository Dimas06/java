/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JOptionPane;
import javax.swing.JOptionPane;
/**
 *
 * @author dimas_06
 */
public class input_example {
    public static void main(String[] args){
        String nama,panggon,gendaanmu; //Variabel String Untuk Menyimpan input
        //memunculkan pesan dialog serta menerima input dari user
        nama = JOptionPane.showInputDialog("Jenengmu sopo?");
        panggon = JOptionPane.showInputDialog("Panggonmu nok ndi?");
        gendaanmu = JOptionPane.showInputDialog("gendaanmu sopo?");
        //Menampilkan kepada user
        JOptionPane.showMessageDialog(null, "salam seduluran "+nama);
        JOptionPane.showMessageDialog(null, "Omahku nok "+panggon);
        JOptionPane.showMessageDialog(null, "aku iku  "+gendaanmu);
    }
}
