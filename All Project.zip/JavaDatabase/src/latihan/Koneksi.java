/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan;
import com.mysql.jdbc.Driver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


/**
 *
 * @author dimas_06
 */
public class Koneksi {
    private static Connection koneksi;
         
    public static Connection GetConnection()throws SQLException{
   if (koneksi==null){
     new Driver();
     
   koneksi=DriverManager.getConnection("jdbc:mysql://localhost/db_mhs","root","");
   
   }
   return koneksi;
 }}


