/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author dimas_06
 */
final class MyClassFinal {
    protected String brand = "Sparco";
    public void honk() {
        System.out.println("Cuit, cuit!");
        
    }
}

class cars extends MyClassFinal{
    private String modelName = "Skyline";
    public static void main (String[] args) {
       cars myFastCars = new cars(); 
       myFastCars.honk();
       System.out.println(myFastCars.brand +" " + myFastCars.modelName);
       
    }
}