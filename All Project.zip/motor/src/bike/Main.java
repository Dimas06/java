/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bike;

/**
 *
 * @author dimas_06
 */
public class Main {
    public static void main(String[] args){
        Bike b1;
        Bike b2;
        
        b1 = new Bike();
        b2 = new Bike();
        
        b1.start();
        b2.start();
        
        b1.accelerate(50);
        
        b1.printState();
        b2.printState();
    }
}


