/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bike;

/**
 *
 * @author dimas_06
 */
public class Bike {
    // Data or Attributes
    
    boolean power;
    int speed;
    
    // Operations or Methods or Behavior
    
    void start() {
        power = true;
        speed = 0;
   }
    
    void stop() {
        power = false ;
        speed = 0;
   }
    void accelerate(int newSpeed) {
        speed = newSpeed;
   }
    void printState() {
        System.out.println("Current state");
        System.out.println("Power -" + power);
        System.out.println("Speed -" + speed);
    }
}

